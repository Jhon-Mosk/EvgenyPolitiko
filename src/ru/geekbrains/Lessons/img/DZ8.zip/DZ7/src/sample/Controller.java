package sample;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;


public class Controller implements Initializable {
    @FXML
    TextArea textArea;

    @FXML
    TextField textField;

    @FXML
    Button btn1;

    @FXML
    TextField loginField;

    @FXML
    TextField passWord;

    @FXML
    Button loginButton;

    @FXML
    HBox upperandclose;

    @FXML
    Button showBlackList;

    @FXML
    ListView<String> contactList;

    @FXML
    VBox list;

    Socket socket;
    DataInputStream in;
    DataOutputStream out;

    final String IP_ADRESS = "localhost";
    final int PORT = 8954;

    private boolean isBlackListShown = false;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            socket = new Socket(IP_ADRESS, PORT);
            in = new DataInputStream(socket.getInputStream());
            out = new DataOutputStream(socket.getOutputStream());

            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        while (true) {

                            String s = in.readUTF();
                            if (s.equals("exit")) break;
                            else {
                                textArea.appendText(s);
                                textArea.appendText("\n");
                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    } finally {
                        try {
                            socket.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                }
            }).start();
        } catch (ConnectException e) {
            textArea.appendText("Server is not available");
            textField.setVisible(false);
            loginField.setVisible(false);
            passWord.setVisible(false);
            loginButton.setVisible(false);
        } catch (IOException e) {
            e.printStackTrace();
        }

        contactList.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
               PersonalMessageDialogue pmd = new PersonalMessageDialogue();
            }
        });
    }

    public void sendMsg() {

        try {
            out.writeUTF(textField.getText() + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
        textField.clear();
        textField.requestFocus();
//        btn1.setVisible(false);
//        btn1.setManaged(false);
    }


    public void authorize() {
        try {
            out.writeUTF(loginField.getText());
            out.writeUTF(passWord.getText());
            upperandclose.setVisible(false);
            upperandclose.setManaged(false);
            list.setVisible(true);
            list.setManaged(true);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void showBlackList() {
        if (isBlackListShown) {
            try {
                out.writeUTF("/getBlackList ");
                String[] list = in.readUTF().split(" ");
                contactList.getItems().clear();
                contactList.getItems().addAll(list);
                isBlackListShown = false;
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            try {
                out.writeUTF("/getClientList ");

                String[] list = in.readUTF().split(" ");
                contactList.getItems().clear();
                contactList.getItems().addAll(list);
                isBlackListShown = true;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }



        }

    }

    class PersonalMessageDialogue implements Runnable {
        @FXML
        java.awt.TextField txtprvtmsg;

        @FXML
        java.awt.Button delete;

        @FXML
        java.awt.Button addtoblack;

        @FXML
        java.awt.Button sendPrivateMessage;

        public String userNick;

        @Override
        public void run() {
            Stage primaryStage = new Stage();
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("pm.fxml"));
            } catch (IOException e) {
                e.printStackTrace();
            }
            primaryStage.setTitle("Private Message");
            Scene scene = new Scene(root, 200, 150);
            primaryStage.setScene(scene);
            //  scene.getStylesheets().add((getClass().getResource("/css/Styles.css")).toExternalForm());
            primaryStage.show();
        }

        void sendPrivateMessage() {

        }

    };
}



