package Server;

import javafx.scene.layout.HBox;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class ClientHandler {
    private Server server = null;
    private Socket socket = null;
    private DataInputStream inputStream;
    private DataOutputStream outputStream;
    private String name;
    private boolean auth = false;

    private boolean isAdmin = false;

    public ClientHandler(Server server, Socket socket) throws IOException {
        this.server = server;
        this.socket = socket;
        this.inputStream = new DataInputStream(socket.getInputStream());
        this.outputStream = new DataOutputStream((socket.getOutputStream()));
        this.name = name;

        authorize();

        new Thread(new Runnable() {
            @Override
            public void run() {

                try {

                    while (true) {
                        if (auth) {
                            String s = inputStream.readUTF();
                            if (s.startsWith("/")) {
                                String keyword = s.split(" ")[0];

                                if (keyword.equals("/exit")) break;
                                else if (keyword.equals("/w") || keyword.equals("/pm") || keyword.equals("/dm")) {
                                    String[] tokens = s.split(" +", 3);
                                    server.sendPM(tokens[1], String.format("%s: %s", name, tokens[2]));
                                    outputStream.writeUTF(String.format("%s: %s", name, tokens[2]));
                                } else if (keyword.equals("/bl") || keyword.equals("/blacklist")) {
                                    String nameOfTheBadPerson = s.split(" +")[1];
                                    AuthService.addToBlackList(name, nameOfTheBadPerson);
                                } else if (keyword.equals("/getBlackList")) {
                                    outputStream.writeUTF(AuthService.getBlackList(name));
                                } else if (keyword.equals("/rmvbl")) {
                                    String nameOfTheBadPerson = s.split(" +")[1];
                                    AuthService.removeFromTheBlackList(name, nameOfTheBadPerson);
                                } else if (keyword.equals("/getClientList")) {
                                    outputStream.writeUTF(AuthService.getClientsOnline());
                                } else if (keyword.equals("/del")) {

                                }
                            } else {
                                server.broadcastMessage(String.format("%s: %s", name, s));
                            }
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        inputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        outputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    try {
                        socket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

        }).start();

    }

    public void sendMessage(String msg) {
        try {
            outputStream.writeUTF(msg);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void authorize() {
        try {
            String login = inputStream.readUTF();
            String password = inputStream.readUTF();
            name = AuthService.getNick(login, password);
            auth = true;
            outputStream.writeUTF("/getClientList");
            isAdmin = AuthService.checkAdmin(name);

        } catch (Exception e) {
        }
    }

    public String getName() {
        return name;
    }
}
