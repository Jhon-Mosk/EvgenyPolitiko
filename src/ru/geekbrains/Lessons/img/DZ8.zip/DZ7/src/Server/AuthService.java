package Server;

import java.sql.*;
import java.util.ArrayList;

public class AuthService {

    private static Connection connection;
    private static Statement statement;

    public static void connect() {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:dz6.db");
            statement = connection.createStatement();
        } catch (Exception e) {

        }
    }

    public static void disconnect() {
        try {
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static String getNick(String login, String pass) {
        String sql = String.format("SELECT nick from Main \n" +
                "where login = '%s'\n" +
                "and password = '%s'", login, pass);

        try {
            ResultSet set = statement.executeQuery(sql);
            if (set.next()) {
                System.out.println(set.getString(1));
                return set.getString(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static String getBlackList(String nick) {
        String sql = String.format("SELECT blacklist from Main where nick = '%s'", nick);
        try {
            ResultSet set = statement.executeQuery(sql);
            if (set.next()) {
                return set.getString(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return sql;
    }

    public static void addToBlackList(String nickOfTheUser, String nickOfTheBadPerson) {
        String bl = getBlackList(nickOfTheUser) + " " + nickOfTheBadPerson;
        String sql = String.format("UPDATE Main SET blacklist = '%s' where nick = '%s';", bl, nickOfTheUser);
        try {
            statement.executeQuery(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void removeFromTheBlackList(String nickOfTheUser, String nickOfTheBadPerson) {
        String[] bList = getBlackList(nickOfTheUser).split(" ");
        String newBlackList = "";
        for (String sbl : bList) {
            if (!sbl.equals(nickOfTheBadPerson)) {
                newBlackList += sbl + " ";
            }
        }
        String sql = String.format("UPDATE Main SET blacklist = '%s' where nick = '%s';", newBlackList, nickOfTheUser);
        try {
            statement.executeQuery(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void setOnline(String nick, int isOnline) {
        String sql = String.format("UPDATE Main SET online = %d where nick = '%s';", isOnline, nick);
        try {
            statement.executeQuery(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static String getClientsOnline() {
        String sql = String.format("SELECT nick from Main where online = 1");
        try {
            ResultSet set = statement.executeQuery(sql);
            String res = new String();

            while (set.next()) {
                res += set.getString(1) + " ";
            }

            return res;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean checkAdmin(String nick) {
        String sql = String.format("SELECT admin from Main where nick='%s'", nick);
        try {
            ResultSet set = statement.executeQuery(sql);

            while (set.next()) {
                if (set.getString(1).equals("1"))
                    return true;
                else return false;
            }


        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}


