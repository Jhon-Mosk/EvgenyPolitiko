package Server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.util.Vector;


public class Server {

    private Vector<ClientHandler> clients;

    public Server() {
        clients = new Vector<>();
        ServerSocket server = null;
        Socket socket = null;
        DataInputStream inputStream;
        DataOutputStream outputStream;
        AuthService.connect();

        try {
            server = new ServerSocket(8954);

            while (true) {
                socket = server.accept();
                clients.addElement(new ClientHandler(this, socket));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void broadcastMessage(String msg) {
        for (ClientHandler client : clients) {
            client.sendMessage(msg);
        }
    }

    public void sendPM(String nickname, String message) {
        for (ClientHandler client : clients) {
            if (client.getName().equals(nickname))
                client.sendMessage(message);
        }
    }
}
