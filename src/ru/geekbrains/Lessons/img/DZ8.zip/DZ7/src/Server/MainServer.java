package Server;

import java.sql.SQLException;

public class MainServer {
    public static void main(String[] args)
    {
        new Server();
    }
}
