package gb;

import gb.server.ClientHandler;

import java.sql.*;
import java.util.*;

/**
 * Created by lipin on 04.07.2018.
 */
public class TestClass {
    private static Connection connection;
    private static Statement stmt;

    public static void connect() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:userTestDB.db");
            stmt = connection.createStatement();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


    public static void setBlacklistClient(String owner, String nick) {
        String sql_max_id = "select max(id) from blacklist";
        int a = 0;
        ResultSet rs = null;
        try {
            rs = stmt.executeQuery(sql_max_id);
            if (rs.next()) {
                a = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }




        String sql_insert = String.format("insert into blacklist (id,owner,b_client) values(%d,'%s', '%s')", a+1, owner, nick);
        try {
            stmt.executeUpdate(sql_insert);
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
    }






    public static void main(String[] args) {
        try {
            TestClass.connect();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        TestClass.setBlacklistClient("nick1", "nick3");
        TestClass.setBlacklistClient("nick1", "nick2");
        System.out.println(mass_black("nick1"));


    }


    public static HashSet<String> mass_black(String owner) {
        HashSet<String> mass = new HashSet<>();
        String sql_black_names = String.format("select b_client from blacklist where owner='%s';",owner);

        ResultSet rs = null;

        try {
            rs = stmt.executeQuery(sql_black_names);
            while (rs.next()) {
                mass.add(rs.getString(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return mass;
    }
}
