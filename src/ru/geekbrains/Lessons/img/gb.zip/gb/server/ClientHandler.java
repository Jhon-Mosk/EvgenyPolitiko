package gb.server;

import gb.TestClass;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.sql.SQLException;
import java.util.ArrayList;

public class ClientHandler {
    private Server server;
    private Socket socket;
    private DataOutputStream out;
    private DataInputStream in;
    private ArrayList<String> blackList;
    private ClientTimerListener listener;

    public String getNick() {
        return nick;
    }

    public boolean checkBlackList(String nick) {
        return AuthService.mass_black(this).contains(nick);
    }

    String nick;

    @Override
    public String toString() {
        return nick;
    }

    public ClientHandler(Server server, Socket socket) {
        try {
            this.socket = socket;
            this.server = server;
            this.in = new DataInputStream(socket.getInputStream());
            this.out = new DataOutputStream(socket.getOutputStream());
            this.blackList = new ArrayList<>();
            Thread t1 = new Thread(() -> {
                try {
                    while (true) {
                        String str = in.readUTF();
                        if(str.startsWith("/auth")) {
                            String[] tokens = str.split(" ");
                            String newNick = AuthService.getNickByLoginAndPass(tokens[1], tokens[2]);

                            if(newNick != null) {
                                if(!server.isNickBusy(newNick)) {
                                    sendMsg("/authok");
                                    nick = newNick;
                                    listener = new ClientTimerListener(this);
                                    server.subscribe(this);

                                    break;
                                } else {
                                    sendMsg("Учетная запись уже используется");
                                }
                            } else {
                                sendMsg("Неверный логин/пароль");
                            }
                        }
                    }
                    while (true) {
                        String str = in.readUTF();
                        if(str.startsWith("/")) {
                            if (str.equals("/end")) {
                                out.writeUTF("/serverclosed");
                                break;
                            }

                            if(str.startsWith("/deluser")){
                                String[] tokens = str.split(" ");
                                deluser(tokens[1]);

                            }

                            if(str.startsWith("/w ")) {
                                String[] tokens = str.split(" ",3);
                                listener.reset();
                                server.sendPersonalMsg(this, tokens[1], tokens[2]);

                            }

                            if(str.startsWith("/blacklist ")) {
                                listener.reset();
                                String[] tokens = str.split(" ");
                                blackList.add(tokens[1]);
                                boolean test=false;
                                for (String b : AuthService.mass_black(ClientHandler.this)) {
                                    if(b.equals(tokens[1])){
                                       test=true;
                                    }
                                }
                                if(test)
                                sendMsg("Пользователь "+tokens[1]+" уже добавлен в черный список");
                                else{
                                    AuthService.setBlacklistClient(this.getNick(),tokens[1]);
                                    sendMsg("Вы добавили пользователя " + tokens[1] + " в черный список");
                                }
                            }



                        } else {
                            listener.reset();
                            server.broadcastMsg(this,nick + " " + str);
                        }
                        System.out.println("Client: " + str);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        in.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        out.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        socket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    server.unsubscribe(this);
                }
            });
            t1.setDaemon(true);
            t1.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void sendMsg(String msg) {
        try {
            out.writeUTF(msg);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public  void deluser(String nick){
        for (ClientHandler o: server.getClients()){
            if(o.getNick().equals(nick)) {
                o.sendMsg("/deluser");
                server.unsubscribe(o);

                try {
                    o.socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }
}

