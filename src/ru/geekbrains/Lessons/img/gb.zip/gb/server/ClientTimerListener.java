package gb.server;

/**
 * Created by lipin on 04.07.2018.
 */
public class ClientTimerListener implements Runnable {
    public int vtimer=120;
    ClientHandler client;

    public ClientTimerListener(ClientHandler client) {
        this.client=client;
        new Thread(this).start();
    }

    @Override
    public void run() {
        try {
            while(vtimer>0) {
                    Thread.sleep(1000);
                    vtimer--;

            }
            client.sendMsg("/timeroff");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }



    }

    public void reset(){
        vtimer=120;
    }
}
